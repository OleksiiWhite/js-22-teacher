# js-22

- Promise API
  - Promise.prototype.then(result)
  - Promise.prototype.catch(error)
  - Promise.prototype.finally()
- Цепочки промисов
- Промисификация функций
- Статические методы:
  - Promise.all()
  - Promise.race()
- Мастерская: ипподром
- Чтиво:
  - [Промисы на примере бургер-вечеринки](https://habr.com/ru/company/nix/blog/323066/)
  - [У нас проблемы с промисами](https://habr.com/ru/company/mailru/blog/269465/)
