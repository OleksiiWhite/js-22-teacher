# js-22

- Chatty events (болтливые события)
- Приёмы throttle и debounce с lodash
- [Ленивая загрузка изображений](https://web.dev/native-lazy-loading/)
  - Нативная с атрибутом loading
  - Библиотека lazysizes
